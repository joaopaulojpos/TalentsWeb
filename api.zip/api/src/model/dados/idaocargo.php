<?php
interface iDAOCargo{

    public function pesquisar(Cargo $cargo, $alt='false' );
}

 ?>