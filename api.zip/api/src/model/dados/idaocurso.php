<?php
interface iDAOCurso{

    public function pesquisar(Curso $curso, $alt='false' );
}

 ?>