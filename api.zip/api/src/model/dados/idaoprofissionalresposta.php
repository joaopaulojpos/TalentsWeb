<?php

interface iDAOProfissionalresposta
{
	public function cadastrarResposta(Profissionalrespota $u);
	//public function ResultadoTesteComp(Alternativaperfilcomp $alternativaperfilcomp, $alt='false' );
}

?>