<?php
interface iDAOCompetenciaTecnica{

	public function pesquisar(CompetenciaTecnica $ct, $alt='false' );
}
?>