<?php
interface iDAOIdioma{

    public function pesquisar(Idioma $idioma, $alt='false' );
}

 ?>