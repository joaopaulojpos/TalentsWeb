<?php
interface iDAOAlternativaperfilcomp{

    public function pesquisar(alternativaperfilcomp $alternativaperfilcomp, $alt='false' );
}

 ?>