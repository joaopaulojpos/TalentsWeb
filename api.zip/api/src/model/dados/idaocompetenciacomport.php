<?php
interface iDAOCompetenciaComport{

	public function pesquisar(CompetenciaComport $cc, $alt='false' );
}
?>