<?php
interface iDAOPerguntaperfilcomp{

    public function listarPerguntas();
    public function listarRespostas($cd_pergunta);
}

 ?>