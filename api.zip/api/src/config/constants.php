<?php

define('PREFIX', 'Talents');
define('PATH', 'localhost/talentsweb/');


?>